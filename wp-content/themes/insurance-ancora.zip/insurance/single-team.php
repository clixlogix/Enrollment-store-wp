<?php
/*
 * Team member
 */
insurance_ancora_storage_set('single_style', 'single-team');

get_template_part('single');
?>