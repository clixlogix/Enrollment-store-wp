<?php
/*
 * Matches item
 */
insurance_ancora_storage_set('single_style', 'single-matches');

get_template_part('single');
?>