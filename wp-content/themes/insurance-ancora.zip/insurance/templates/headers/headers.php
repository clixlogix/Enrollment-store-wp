<?php
// Autoload layouts in this folder
insurance_ancora_autoload_folder( 'templates/headers' );
?>