<?php
/*
 * Players item
 */
insurance_ancora_storage_set('single_style', 'single-players');

get_template_part('single');
?>